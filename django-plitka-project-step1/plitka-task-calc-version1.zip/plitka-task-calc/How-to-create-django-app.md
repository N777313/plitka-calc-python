# https://www.w3schools.com/django/django_create_app.php

Create App
I will name my app members.

Start by navigating to the selected location where you want to store the app, in my case the my_tennis_club folder, and run the command below.

If the server is still running, and you are not able to write commands, press [CTRL] [BREAK], or [CTRL] [C] to stop the server and you should be back in the virtual environment.

python manage.py startapp members
Django creates a folder named members in my project, with this content:












# Concole run by Nurlan



magdiyadmin@magdiyadmin-VirtualBox:~/Desktop/django-projects/plitka-task-calc/django-on-docker/app$ ls -alh
total 152K
drwxrwxr-x 4 magdiyadmin magdiyadmin 4,0K Жел  3 19:57 .
drwxrwxr-x 3 magdiyadmin magdiyadmin 4,0K Жел  3 19:46 ..
-rw-r--r-- 1 magdiyadmin magdiyadmin 128K Жел  3 19:48 db.sqlite3
-rwxrwxr-x 1 magdiyadmin magdiyadmin  670 Жел  3 19:48 manage.py
drwxrwxr-x 5 magdiyadmin magdiyadmin 4,0K Жел  3 19:47 myenv1
drwxrwxr-x 3 magdiyadmin magdiyadmin 4,0K Жел  3 19:59 project_django
-rwxrwxr-x 1 magdiyadmin magdiyadmin   40 Жел  3 19:57 run-django.sh
magdiyadmin@magdiyadmin-VirtualBox:~/Desktop/django-projects/plitka-task-calc/django-on-docker/app$ source myenv1/bin/activate
(myenv1) magdiyadmin@magdiyadmin-VirtualBox:~/Desktop/django-projects/plitka-task-calc/django-on-docker/app$ django-admin --version
4.2.3
(myenv1) magdiyadmin@magdiyadmin-VirtualBox:~/Desktop/django-projects/plitka-task-calc/django-on-docker/app$ ls -alh
total 152K
drwxrwxr-x 4 magdiyadmin magdiyadmin 4,0K Жел  3 19:57 .
drwxrwxr-x 3 magdiyadmin magdiyadmin 4,0K Жел  3 19:46 ..
-rw-r--r-- 1 magdiyadmin magdiyadmin 128K Жел  3 19:48 db.sqlite3
-rwxrwxr-x 1 magdiyadmin magdiyadmin  670 Жел  3 19:48 manage.py
drwxrwxr-x 5 magdiyadmin magdiyadmin 4,0K Жел  3 19:47 myenv1
drwxrwxr-x 3 magdiyadmin magdiyadmin 4,0K Жел  3 19:59 project_django
-rwxrwxr-x 1 magdiyadmin magdiyadmin   40 Жел  3 19:57 run-django.sh
(myenv1) magdiyadmin@magdiyadmin-VirtualBox:~/Desktop/django-projects/plitka-task-calc/django-on-docker/app$
(myenv1) magdiyadmin@magdiyadmin-VirtualBox:~/Desktop/django-projects/plitka-task-calc/django-on-docker/app$
(myenv1) magdiyadmin@magdiyadmin-VirtualBox:~/Desktop/django-projects/plitka-task-calc/django-on-docker/app$
(myenv1) magdiyadmin@magdiyadmin-VirtualBox:~/Desktop/django-projects/plitka-task-calc/django-on-docker/app$ python manage.py startapp mainapp
(myenv1) magdiyadmin@magdiyadmin-VirtualBox:~/Desktop/django-projects/plitka-task-calc/django-on-docker/app$ ls -alh
total 156K
drwxrwxr-x 5 magdiyadmin magdiyadmin 4,0K Жел  3 20:07 .
drwxrwxr-x 3 magdiyadmin magdiyadmin 4,0K Жел  3 19:46 ..
-rw-r--r-- 1 magdiyadmin magdiyadmin 128K Жел  3 19:48 db.sqlite3
drwxrwxr-x 3 magdiyadmin magdiyadmin 4,0K Жел  3 20:07 mainapp
-rwxrwxr-x 1 magdiyadmin magdiyadmin  670 Жел  3 19:48 manage.py
drwxrwxr-x 5 magdiyadmin magdiyadmin 4,0K Жел  3 19:47 myenv1
drwxrwxr-x 3 magdiyadmin magdiyadmin 4,0K Жел  3 19:59 project_django
-rwxrwxr-x 1 magdiyadmin magdiyadmin   40 Жел  3 19:57 run-django.sh
