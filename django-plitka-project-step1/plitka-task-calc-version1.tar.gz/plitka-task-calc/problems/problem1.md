# зашел на сайт http://192.168.100.125:8000/mainapp

ошибка:
Page not found (404)
Request Method:	GET
Request URL:	http://192.168.100.125:8000/mainapp
Using the URLconf defined in project_django.urls, Django tried these URL patterns, in this order:

admin/
The current path, mainapp, didn’t match any of these.

You’re seeing this error because you have DEBUG = True in your Django settings file. Change that to False, and Django will display a standard 404 page.


# solution: 

Эта ошибка говорит о том, что по адресу:

```
/mainapp
```

**нет зарегистрированного URL-маршрута**.

Django показывает, что в проекте сейчас есть только:

```
admin/
```

И больше ничего.

---

# 🔍 Почему так?

Скорее всего:

1. Ты создал приложение `mainapp`, но
2. Не добавил его `urls.py` в главный `urls.py` проекта
   **или**
3. Внутри `mainapp.urls` нет маршрута без `/` на конце.

---

# ✅ Как исправить (пошагово)

## 1️⃣ Убедись, что `mainapp` добавлен в `INSTALLED_APPS`

В `project_django/settings.py`:

```python
INSTALLED_APPS = [
    ...,
    "mainapp",
]
```

---

## 2️⃣ Создай файл `mainapp/urls.py`, если его нет

```python
from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="mainapp-index"),
]
```

---

## 3️⃣ Добавь маршрут в главный `urls.py`

Файл: `project_django/urls.py`

```python
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("mainapp/", include("mainapp.urls")),
]
```

Обрати внимание:
Теперь URL будет:

```
http://192.168.100.125:8000/mainapp/
```

А не `/mainapp`
(URL Django всегда должен **заканчиваться слэшем**, если не указано иначе)

---

## 4️⃣ Создай view, если его нет

`mainapp/views.py`:

```python
from django.http import HttpResponse

def index(request):
    return HttpResponse("Hello from mainapp!")
```

---

# 🔧 Проверка

Теперь:

```
http://192.168.100.125:8000/mainapp/
```

должен работать.

---

# ❗ Если хочешь, могу:

✅ проверить твой текущий код
✅ собрать корректную структуру проекта
✅ объяснить, почему `/mainapp` без `/` вызывает 404
✅ сделать красивый шаблон + CBV + маршрутизацию

Хочешь — покажи структуру проекта командой:

```bash
tree -L 3
```

